#include "syscall.h"

main(){
  int i; 
  for(i=0; i<10; i++){
     // time unit: milliseconds
     Sleep(10000);
     // do some work
     PrintInt(333);
  }

  return 0;
}
