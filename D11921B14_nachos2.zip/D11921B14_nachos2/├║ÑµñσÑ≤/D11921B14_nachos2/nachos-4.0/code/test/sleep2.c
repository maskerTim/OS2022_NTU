#include "syscall.h"

main(){
   int i;
   for(i=0; i<15; i++){
      // time unit: milliseconds
      Sleep(30000);
      // do some work
      PrintInt(33333);
   }

  return 0;
}
